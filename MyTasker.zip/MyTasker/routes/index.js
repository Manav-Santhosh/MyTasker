const { request } = require('express');
var express = require('express');
var router = express.Router();
var taskCollection=require('./users')


/* GET home page. */
router.get('/', function(req, res, next) {
  res.render('index', { title: 'Express' });
});
router.post('/addtask', function(req, res, next) {
  taskCollection.create({
    content:req.body.taskJumper
  })
  .then(()=>{
    res.redirect('/')
  })
}) 

module.exports = router;
