var mongo=require("mongoose")
mongo.connect('mongodb://localhost/task');
var schema=mongo.Schema(
  {content:{
    type:String,
    required:true
  }}
)
module.exports=mongo.model('tasks',schema)